import streamlit as st
import joblib
import pandas as pd

# Load model
model = joblib.load('car_price_model.pkl')

st.title("Car Price Prediction")

# User inputs
year = st.number_input('Year of Purchase', 1990, 2025, 2015)
present_price = st.number_input('Present Price (in lakhs)', 0.0, 100.0, 5.0)
kms_driven = st.number_input('Kms Driven', 0, 500000, 30000)
fuel_type = st.selectbox('Fuel Type', ['Petrol', 'Diesel', 'CNG'])
seller_type = st.selectbox('Seller Type', ['Dealer', 'Individual'])
transmission = st.selectbox('Transmission', ['Manual', 'Automatic'])

# Prepare input dataframe for prediction
input_df = pd.DataFrame({
    'Year': [year],
    'Present_Price': [present_price],
    'Kms_Driven': [kms_driven],
    'Fuel_Type': [fuel_type],
    'Seller_Type': [seller_type],
    'Transmission': [transmission]
})

if st.button('Predict Selling Price'):
    prediction = model.predict(input_df)[0]
    st.success(f"Estimated Selling Price: ₹{prediction:.2f} lakhs")
